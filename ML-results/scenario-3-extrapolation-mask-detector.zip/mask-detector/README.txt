SCENARIO 3

Data used was from the full workflow
Models were trained on data from runs 5 and 10 videos, then tested on 15 videos
